package com.exam.repository;

import org.springframework.data.repository.CrudRepository;

import com.exam.beans.BillingDetails;

public interface BillingDetailsRepository extends CrudRepository<BillingDetails,String>{

}
