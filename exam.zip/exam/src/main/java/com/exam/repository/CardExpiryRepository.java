package com.exam.repository;

import org.springframework.data.repository.CrudRepository;

import com.exam.beans.CardExpiry;

public interface CardExpiryRepository extends CrudRepository<CardExpiry,String> {

}
