package com.exam.repository;

import org.springframework.data.repository.CrudRepository;

import com.exam.beans.Card;


public interface CardRepository extends CrudRepository<Card,String> {

}
