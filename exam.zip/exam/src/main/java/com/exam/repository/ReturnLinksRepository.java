package com.exam.repository;

import org.springframework.data.repository.CrudRepository;

import com.exam.beans.ReturnLinks;

public interface ReturnLinksRepository extends CrudRepository<ReturnLinks,String> {

}
