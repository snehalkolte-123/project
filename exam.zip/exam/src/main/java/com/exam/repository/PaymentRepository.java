package com.exam.repository;

import org.springframework.data.repository.CrudRepository;

import com.exam.beans.PaymentMethod;

public interface PaymentRepository extends CrudRepository<PaymentMethod,String> {

}
