package com.exam.beans;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PaymentMethod 
{
  @Id
  private String id;
  private int amount;
  private String merchantRefNum;
  private String action;
  private String currencyCode;
  private String usage;
  private String status;
  private String name;
  private int timeToLiveSeconds;
  private String transactionType;
  private String paymentType;
  private String executionMode;
  private String customerIp;
  private String paymentHandleToken;
  
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public int getAmount() {
	return amount;
}
public void setAmount(int amount) {
	this.amount = amount;
}
public String getMerchantRefNum() {
	return merchantRefNum;
}
public void setMerchantRefNum(String merchantRefNum) {
	this.merchantRefNum = merchantRefNum;
}
public String getAction() {
	return action;
}
public void setAction(String action) {
	this.action = action;
}
public String getCurrencyCode() {
	return currencyCode;
}
public void setCurrencyCode(String currencyCode) {
	this.currencyCode = currencyCode;
}
public String getUsage() {
	return usage;
}
public void setUsage(String usage) {
	this.usage = usage;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getTimeToLiveSeconds() {
	return timeToLiveSeconds;
}
public void setTimeToLiveSeconds(int timeToLiveSeconds) {
	this.timeToLiveSeconds = timeToLiveSeconds;
}
public String getTransactionType() {
	return transactionType;
}
public void setTransactionType(String transactionType) {
	this.transactionType = transactionType;
}
public String getPaymentType() {
	return paymentType;
}
public void setPaymentType(String paymentType) {
	this.paymentType = paymentType;
}
public String getExecutionMode() {
	return executionMode;
}
public void setExecutionMode(String executionMode) {
	this.executionMode = executionMode;
}
public String getCustomerIp() {
	return customerIp;
}
public void setCustomerIp(String customerIp) {
	this.customerIp = customerIp;
}
public String getPaymentHandleToken() {
	return paymentHandleToken;
}
public void setPaymentHandleToken(String paymentHandleToken) {
	this.paymentHandleToken = paymentHandleToken;
}
@Override
public String toString() 
{
	return "PaymentMethod [id=" + id + ", amount=" + amount + ", merchantRefNum=" + merchantRefNum + ", action="
			+ action + ", currencyCode=" + currencyCode + ", usage=" + usage + ", status=" + status + ", name=" + name
			+ ", timeToLiveSeconds=" + timeToLiveSeconds + ", transactionType=" + transactionType + ", paymentType="
			+ paymentType + ", executionMode=" + executionMode + ", customerIp=" + customerIp + ", paymentHandleToken="
			+ paymentHandleToken + "]";
}
}
